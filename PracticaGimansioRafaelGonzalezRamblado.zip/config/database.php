<?php
/**
 * Parámetros de configuración de la base de datos
 */

define('DBDRIVER', 'mysql');
define('DBHOST', 'localhost');
define('DBNAME', 'gimnasio');
define('DBUSER', 'gimnasio');
define('DBPASS', 'gimnasio');


