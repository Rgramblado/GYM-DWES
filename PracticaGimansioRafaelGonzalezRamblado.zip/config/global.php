<?php
/**
 * Parámetros de configuración globales
 * Definidos como constantes define
 */
define('CONTROLLERS_FOLDER', 'controllers/');
define('MODELS_FOLDER', 'models/');
define('VIEWS_FOLDER', 'views/');

define('DEFAULT_CONTROLLER', 'Index');
define('DEFAULT_ACTION', 'index');